This non-module version of the OrbitControlsGizmo can be used directly in the `HTML` with either of below:
 - `<script src="OrbitControlsGizmo.js"></script>` - if no path is required
 - `<script src="../static/js/OrbitControlsGizmo.js"></script>` - with some path added

It has been used as such in Three.js viewers found on the [webpage](https://githubdragonfly.github.io/).
