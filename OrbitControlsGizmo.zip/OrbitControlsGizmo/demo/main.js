import * as THREE from "http://localhost/html/three.js-dev/build/three.module.js";
import { GUI } from "https://unpkg.com/dat.gui@0.7.7/build/dat.gui.module.js";

import { OrbitControls } from "../OrbitControls2.js";
import { TrackballControls } from "../TrackballControls.js";
import { ArcballControls } from "../ArcballControls.js";

import { OrbitControlsGizmo } from "../OrbitControlsGizmo_v1.js";

var mesh, renderer, scene, camera, controls, controlsGizmo;

init();
//animate();


function init() {

  // renderer
  renderer = new THREE.WebGLRenderer( { antialias: true } );
  renderer.setSize( window.innerWidth, window.innerHeight );
  renderer.setClearColor(new THREE.Color(0x333333));
  renderer.setPixelRatio( window.devicePixelRatio );
  document.body.appendChild( renderer.domElement );

  // scene
  scene = new THREE.Scene();
  
  // camera
  camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 0.1, 10000 );
  camera.position.set( 15, 12, 12 );
  console.log( camera)

  // Orbit Controls
  //controls = new OrbitControls( camera, renderer.domElement );
  //controls = new TrackballControls( camera, renderer.domElement );
  controls = new ArcballControls( camera, renderer.domElement, scene );
  controls.object = controls.camera;
  controls.setGizmosVisible( false );
  console.log( controls)
  window.controls = controls;
 
  // Obit Controls Gizmo
  controlsGizmo = new OrbitControlsGizmo(controls, { size: 500, padding: 50 });

  // Add the Gizmo to the document
  document.body.appendChild(controlsGizmo.domElement);
  
  
  console.log(controlsGizmo);
  
  controlsGizmo.dispose();
  // Obit Controls Gizmo
  controlsGizmo = new OrbitControlsGizmo(controls, { size: 100, padding: 5 });

  // Add the Gizmo to the document
  document.body.appendChild( controlsGizmo.domElement );

  controls.addEventListener('change', render);

  







  // ambient light
  scene.add( new THREE.AmbientLight( 0x222222 ) );
  
  // directional light
  var light = new THREE.DirectionalLight( 0xffffff, 1 );
  light.position.set( 2,2, 0 );
  scene.add( light );
  var geometry = new THREE.ConeGeometry( 5, 20, 32 );
  
  // material
  var material = new THREE.MeshPhongMaterial( {
    color: 0x00ffff, 
    transparent: true,
    opacity: 0.7,
  });
  
  // mesh
  mesh = new THREE.Mesh( geometry, material );
  mesh.position.set(0, 0.5, 0);
  scene.add( mesh );
  
  render();

  // GUI
  //const gui = new GUI();
  //gui.add(controls, 'enabled').name("Enable Orbit Controls");
  //gui.add(controlsGizmo, 'lock').name("Lock Gizmo");
  //gui.add(controlsGizmo, 'lockX').name("Lock Gizmo's X Axis");
  //gui.add(controlsGizmo, 'lockY').name("Lock Gizmo's Y Axis");

}

function animate() {

  requestAnimationFrame( animate );
  renderer.render( scene, camera );
  controls.update();

}

function render() {
  renderer.render( scene, camera );
  controls.update();

}


function resize() {
  renderer.setSize( window.innerWidth, window.innerHeight );
  camera.aspect = ( window.innerWidth / window.innerHeight );
  camera.updateProjectionMatrix();
}

window.onresize = resize;
